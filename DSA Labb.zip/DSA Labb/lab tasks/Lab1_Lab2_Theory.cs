using System;

namespace LabTasks;

public static class Lab1_Lab2_Theory
{
    public static void Run()
    {
        Console.WriteLine("Lab 1 & Lab 2 Theory");

        int[] numbers = { 4, 8, 12, 16, 20, 24, 28 };
        int key = 16;

        Console.WriteLine("Linear Search Example");
        Console.WriteLine($"Target {key} found at index {LinearSearch(numbers, key)}");

        Console.WriteLine("Binary Search Example");
        Console.WriteLine($"Target {key} found at index {BinarySearch(numbers, key)}");

        Console.WriteLine("Time Complexity Summary:");
        Console.WriteLine("O(1): Constant time access to an array index.");
        Console.WriteLine("O(log n): Binary search in a sorted array.");
        Console.WriteLine("O(n): Linear search or traversing an array once.");
        Console.WriteLine("O(n^2): Nested loops when scanning matrix-like data.");

        Console.WriteLine($"Array average: {CalculateAverage(numbers):F2}");
    }

    public static int LinearSearch(int[] array, int target)
    {
        for (int i = 0; i < array.Length; i++)
        {
            if (array[i] == target)
            {
                return i;
            }
        }

        return -1;
    }

    public static int BinarySearch(int[] array, int target)
    {
        int left = 0;
        int right = array.Length - 1;

        while (left <= right)
        {
            int middle = left + (right - left) / 2;

            if (array[middle] == target)
            {
                return middle;
            }

            if (array[middle] < target)
            {
                left = middle + 1;
            }
            else
            {
                right = middle - 1;
            }
        }

        return -1;
    }

    public static double CalculateAverage(int[] array)
    {
        if (array == null || array.Length == 0)
        {
            throw new ArgumentException("Array cannot be empty.");
        }

        int total = 0;
        foreach (int value in array)
        {
            total += value;
        }

        return total / (double)array.Length;
    }
}
