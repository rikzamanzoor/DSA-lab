using System;

namespace LabTasks;

public static class Lab0_Introduction
{
    public static void Run()
    {
        Console.WriteLine("Lab 0 - Introduction");

        string studentName = "Khaleel";
        int rollNumber = 101;
        double marks = 82.5;

        Console.WriteLine($"Student: {studentName}");
        Console.WriteLine($"Roll Number: {rollNumber}");
        Console.WriteLine($"Marks: {marks}");

        int a = 15;
        int b = 25;
        int sum = a + b;
        int product = a * b;

        Console.WriteLine($"Sum = {sum}");
        Console.WriteLine($"Product = {product}");

        Console.WriteLine("Even numbers from 1 to 10:");
        for (int i = 1; i <= 10; i++)
        {
            if (i % 2 == 0)
            {
                Console.Write(i + " ");
            }
        }

        Console.WriteLine();
    }

    public static double CalculateAverage(params int[] values)
    {
        if (values == null || values.Length == 0)
        {
            throw new ArgumentException("At least one value is required.");
        }

        int total = 0;
        foreach (int value in values)
        {
            total += value;
        }

        return total / (double)values.Length;
    }
}
