using System;

namespace LabTasks;

public static class Lab1_Array
{
    public static void Run()
    {
        Console.WriteLine("Lab 1 - Arrays");

        int[] numbers = { 10, 20, 30, 40 };
        Console.WriteLine("Original array:");
        PrintArray(numbers);

        int[] appended = InsertAtEnd(numbers, 50);
        Console.WriteLine("After inserting 50 at end:");
        PrintArray(appended);

        int[] insertedFront = InsertAtBeginning(numbers, 5);
        Console.WriteLine("After inserting 5 at beginning:");
        PrintArray(insertedFront);

        int[] updated = UpdateAtPosition(numbers, 1, 99);
        Console.WriteLine("After updating index 1 to 99:");
        PrintArray(updated);

        Console.WriteLine($"Search for 30: index {LinearSearch(numbers, 30)}");
        Console.WriteLine($"Max value: {FindMax(numbers)}");
        Console.WriteLine($"Average: {CalculateAverage(numbers):F2}");
    }

    public static int[] InsertAtEnd(int[] array, int value)
    {
        int[] result = new int[array.Length + 1];
        Array.Copy(array, result, array.Length);
        result[result.Length - 1] = value;
        return result;
    }

    public static int[] InsertAtBeginning(int[] array, int value)
    {
        int[] result = new int[array.Length + 1];
        result[0] = value;
        Array.Copy(array, 0, result, 1, array.Length);
        return result;
    }

    public static int[] UpdateAtPosition(int[] array, int index, int newValue)
    {
        if (index < 0 || index >= array.Length)
        {
            throw new IndexOutOfRangeException("Index is out of range.");
        }

        int[] result = (int[])array.Clone();
        result[index] = newValue;
        return result;
    }

    public static int LinearSearch(int[] array, int target)
    {
        for (int i = 0; i < array.Length; i++)
        {
            if (array[i] == target)
            {
                return i;
            }
        }

        return -1;
    }

    public static int FindMax(int[] array)
    {
        if (array == null || array.Length == 0)
        {
            throw new ArgumentException("Array cannot be empty.");
        }

        int max = array[0];
        for (int i = 1; i < array.Length; i++)
        {
            if (array[i] > max)
            {
                max = array[i];
            }
        }

        return max;
    }

    public static double CalculateAverage(int[] array)
    {
        if (array == null || array.Length == 0)
        {
            throw new ArgumentException("Array cannot be empty.");
        }

        int total = 0;
        foreach (int value in array)
        {
            total += value;
        }

        return total / (double)array.Length;
    }

    public static void PrintArray(int[] array)
    {
        Console.Write("[");
        for (int i = 0; i < array.Length; i++)
        {
            Console.Write(array[i]);
            if (i < array.Length - 1)
            {
                Console.Write(", ");
            }
        }
        Console.WriteLine("]");
    }
}
