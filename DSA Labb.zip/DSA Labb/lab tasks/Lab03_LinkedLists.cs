using System;

namespace LabTasks;

public class Node
{
    public int Value { get; set; }
    public Node? Next { get; set; }

    public Node(int value)
    {
        Value = value;
        Next = null;
    }
}

public class LinkedListDemo
{
    public Node? Head { get; private set; }

    public void InsertAtBeginning(int value)
    {
        Node newNode = new Node(value)
        {
            Next = Head
        };
        Head = newNode;
    }

    public void InsertAtEnd(int value)
    {
        Node newNode = new Node(value);

        if (Head == null)
        {
            Head = newNode;
            return;
        }

        Node current = Head;
        while (current.Next != null)
        {
            current = current.Next;
        }

        current.Next = newNode;
    }

    public bool DeleteFromBeginning()
    {
        if (Head == null)
        {
            return false;
        }

        Head = Head.Next;
        return true;
    }

    public bool DeleteAtEnd()
    {
        if (Head == null)
        {
            return false;
        }

        if (Head.Next == null)
        {
            Head = null;
            return true;
        }

        Node current = Head;
        while (current.Next != null && current.Next.Next != null)
        {
            current = current.Next;
        }

        current.Next = null;
        return true;
    }

    public bool Search(int target)
    {
        Node? current = Head;
        while (current != null)
        {
            if (current.Value == target)
            {
                return true;
            }

            current = current.Next;
        }

        return false;
    }

    public int Count()
    {
        int count = 0;
        Node? current = Head;

        while (current != null)
        {
            count++;
            current = current.Next;
        }

        return count;
    }

    public void Display()
    {
        Node? current = Head;
        Console.Write("Head -> ");

        while (current != null)
        {
            Console.Write(current.Value + " -> ");
            current = current.Next;
        }

        Console.WriteLine("null");
    }
}

public static class Lab03_LinkedLists
{
    public static void Run()
    {
        Console.WriteLine("Lab 03 - Linked Lists");

        LinkedListDemo list = new LinkedListDemo();
        list.InsertAtBeginning(10);
        list.InsertAtBeginning(20);
        list.InsertAtEnd(30);
        list.InsertAtEnd(40);

        Console.WriteLine("Linked list contents:");
        list.Display();

        Console.WriteLine($"Contains 30: {list.Search(30)}");
        Console.WriteLine($"Node count: {list.Count()}");

        list.DeleteFromBeginning();
        Console.WriteLine("After deleting from beginning:");
        list.Display();

        list.DeleteAtEnd();
        Console.WriteLine("After deleting from end:");
        list.Display();
    }
}
